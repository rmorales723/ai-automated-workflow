package com.robertmorales.handson3;
public class HandsOn
{

	public static void main(String[] args) 
	{			
		// TODO Auto-generated method stub
		int count = 7;
		int[] values =  new int[count];
		
		
		for(int i = 0; i<values.length; i++)
		{
			System.out.printf("Currently item %d contains %d. Please enter a new value", i, values[i]);
			values[i] = StudentHelper.ReadInputInt();
		}
		
			
		for (int val: values)
		{
			System.out.printf("Currently the value is %d%n", val);
		}
	
		for (int i = values.length -1; i >= 0; i--)
		{
			System.out.printf("Currently item %d contains %d%n", i, values[i]);
//			values[i] = StudentHelper.ReadInputInt();
		}
		
		for (int i = 0; i < values.length; i++)
		{
			if ( i % 2 == 0 )
			{
				System.out.printf("Odd index %d has the value %d%n", i,  values[i]);
//				values[i] = StudentHelper.ReadInputInt();
			}
		}
			
	}
	
}

